jre 환경 맞춰주어야 함.
xml config 파일이 존재해야 실행이 가능해보임.

https://yangyag.tistory.com/139
제작 관련 페이지