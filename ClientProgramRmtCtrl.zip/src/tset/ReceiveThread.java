package tset;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.InputStream;
import java.net.Socket;

public class ReceiveThread extends Thread {

	private Socket socket;
	String mouseMoveBuffer = "";
	String[] mouseMove; // ����
	int x = 0; // ���콺 ������ x
	int y = 0; // ���콺 ������ y
	int click = 0; // ���콺 Ŭ��
	int key = 0; // Ű��
	int spKey = 0; // Ư��Ű��
	int spKey2 = 0; // Ư��Ű��2

	@Override
	public void run() {
		super.run();

		try {
			Robot robot = new Robot();

			InputStream in = socket.getInputStream();
			DataInputStream dis = new DataInputStream(in);
			while (true) {
				// ���� �κп� �Ʒ�ó�� ���� �ð��� ����ϰ�

				long start = System.currentTimeMillis();

				// ���콺 �̵� ����
				// System.out.println(dis.readUTF());
				mouseMoveBuffer = dis.readUTF();
				String[] mouseMove = mouseMoveBuffer.split("/");
				String x_str = mouseMove[0]; // ���콺 �̵�
				String y_str = mouseMove[1]; // ���콺 �̵�
				String c_str = mouseMove[2]; // ���콺 Ŭ�� ��
				String k_str = mouseMove[3];
				String spKey_str = mouseMove[4];
				String spKey2_str = mouseMove[5];

				System.out.println(c_str + "���� �Էµǰ� �ֽ��ϴ�.");
				x = Integer.parseInt(x_str);
				y = Integer.parseInt(y_str);
				click = Integer.parseInt(c_str);
				key = Integer.parseInt(k_str);
				spKey = Integer.parseInt(spKey_str);
				spKey2 = Integer.parseInt(spKey2_str);

				if (x != 0 || y != 0) {
					robot.mouseMove(x, y - 30);
				}

				if (click == 1) {
					robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // ���콺 ���� ��ư Ŭ��.
					robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // ���콺 ���� ��ư Ŭ�� ���¸� ���� �����ν� ��.
					click = 0;
				}

				if (key == 1) {

					robot.keyPress(KeyEvent.VK_A);
					robot.keyRelease(KeyEvent.VK_A);
					key = 0;

				} else if (key == 2) {
					robot.keyPress(KeyEvent.VK_B);
					robot.keyRelease(KeyEvent.VK_B);
					key = 0;

				} else if (key == 3) {

					robot.keyPress(KeyEvent.VK_C);
					robot.keyRelease(KeyEvent.VK_C);
					key = 0;

				} else if (key == 4) {

					robot.keyPress(KeyEvent.VK_D);
					robot.keyRelease(KeyEvent.VK_D);
					key = 0;

				} else if (key == 5) {

					robot.keyPress(KeyEvent.VK_E);
					robot.keyRelease(KeyEvent.VK_E);
					key = 0;

				} else if (key == 6) {

					robot.keyPress(KeyEvent.VK_F);
					robot.keyRelease(KeyEvent.VK_F);
					key = 0;

				} else if (key == 7) {

					robot.keyPress(KeyEvent.VK_G);
					robot.keyRelease(KeyEvent.VK_G);
					key = 0;

				} else if (key == 8) {

					robot.keyPress(KeyEvent.VK_H);
					robot.keyRelease(KeyEvent.VK_H);
					key = 0;

				} else if (key == 9) {

					robot.keyPress(KeyEvent.VK_I);
					robot.keyRelease(KeyEvent.VK_I);
					key = 0;

				} else if (key == 10) {

					robot.keyPress(KeyEvent.VK_J);
					robot.keyRelease(KeyEvent.VK_J);
					key = 0;

				} else if (key == 11) {

					robot.keyPress(KeyEvent.VK_K);
					robot.keyRelease(KeyEvent.VK_K);
					key = 0;

				} else if (key == 12) {

					robot.keyPress(KeyEvent.VK_L);
					robot.keyRelease(KeyEvent.VK_L);
					key = 0;

				} else if (key == 13) {

					robot.keyPress(KeyEvent.VK_M);
					robot.keyRelease(KeyEvent.VK_M);
					key = 0;

				} else if (key == 14) {

					robot.keyPress(KeyEvent.VK_N);
					robot.keyRelease(KeyEvent.VK_N);
					key = 0;

				} else if (key == 15) {

					robot.keyPress(KeyEvent.VK_O);
					robot.keyRelease(KeyEvent.VK_O);
					key = 0;

				} else if (key == 16) {

					robot.keyPress(KeyEvent.VK_P);
					robot.keyRelease(KeyEvent.VK_P);
					key = 0;

				} else if (key == 17) {

					robot.keyPress(KeyEvent.VK_Q);
					robot.keyRelease(KeyEvent.VK_Q);
					key = 0;

				} else if (key == 18) {

					robot.keyPress(KeyEvent.VK_R);
					robot.keyRelease(KeyEvent.VK_R);
					key = 0;

				} else if (key == 19) {

					robot.keyPress(KeyEvent.VK_S);
					robot.keyRelease(KeyEvent.VK_S);
					key = 0;

				} else if (key == 20) {

					robot.keyPress(KeyEvent.VK_T);
					robot.keyRelease(KeyEvent.VK_T);
					key = 0;

				} else if (key == 21) {

					robot.keyPress(KeyEvent.VK_U);
					robot.keyRelease(KeyEvent.VK_U);
					key = 0;

				} else if (key == 22) {

					robot.keyPress(KeyEvent.VK_V);
					robot.keyRelease(KeyEvent.VK_V);
					key = 0;

				} else if (key == 23) {

					robot.keyPress(KeyEvent.VK_W);
					robot.keyRelease(KeyEvent.VK_W);
					key = 0;

				} else if (key == 24) {

					robot.keyPress(KeyEvent.VK_X);
					robot.keyRelease(KeyEvent.VK_X);
					key = 0;

				} else if (key == 25) {

					robot.keyPress(KeyEvent.VK_Y);
					robot.keyRelease(KeyEvent.VK_Y);
					key = 0;

				} else if (key == 26) {

					robot.keyPress(KeyEvent.VK_Z);
					robot.keyRelease(KeyEvent.VK_Z);
					key = 0;

				} else {
					key = 0;
				}

				if (spKey == 27) {

					robot.keyPress(KeyEvent.VK_ENTER);
					robot.keyRelease(KeyEvent.VK_ENTER);
					spKey = 0;

				} else if (spKey == 28) {

					robot.keyPress(KeyEvent.VK_SPACE);
					robot.keyRelease(KeyEvent.VK_SPACE);
					spKey = 0;

				} else if (spKey == 29) {

					robot.keyPress(KeyEvent.VK_CONTROL);
					robot.keyRelease(KeyEvent.VK_CONTROL);
					spKey = 0;

				} else if (spKey == 30) {

					robot.keyPress(KeyEvent.VK_ALT);

					if (spKey2 == 29) {

						robot.keyPress(KeyEvent.VK_CONTROL);
						robot.keyRelease(KeyEvent.VK_CONTROL);
						robot.keyRelease(KeyEvent.VK_ALT);
						spKey = 0;
						spKey2 = 0;

					} else {

						robot.keyRelease(KeyEvent.VK_ALT);
						spKey = 0;
						spKey2 = 0;
					}
				} else if (spKey == 31) {

					robot.keyPress(KeyEvent.VK_SHIFT);
					robot.keyRelease(KeyEvent.VK_SHIFT);
					spKey = 0;

				} else if (spKey == 32) {

					robot.keyPress(KeyEvent.VK_BACK_SPACE);
					robot.keyRelease(KeyEvent.VK_BACK_SPACE);
					spKey = 0;

				} else {
					spKey = 0;
				}

				Thread.sleep(48);		//������ 50 Ŭ���̾�Ʈ 48
				
				// ���� �Ʒ��� ���� ����
				long end = System.currentTimeMillis();
				System.out.println( "���� �ð� : " + ( end - start )/1000.0 );
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

}
